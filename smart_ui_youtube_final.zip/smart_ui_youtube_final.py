# smart_ui_youtube_final_v2.py
import cv2
import mediapipe as mp
import pyautogui
import pygetwindow as gw
import webbrowser
import screen_brightness_control as sbc
import time
import threading
from tkinter import Tk, Label, Button

# Import FER safely
try:
    from fer import FER
except Exception:
    from fer.fer import FER

# ---------- Configuration ----------
YOUTUBE_URL = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"  # 🔹 Put your YouTube video link here
HEAD_TURN_ANGLE = 15
BRIGHT_FOCUS = 80
BRIGHT_NORMAL = 40
SAD_TIME = 3
SAD_SCORE_THRESHOLD = 0.4
ACTION_DELAY = 2.0

# Initialize models
mp_face = mp.solutions.face_mesh
face_mesh = mp_face.FaceMesh(max_num_faces=1)
emotion_detector = FER(mtcnn=True)
pyautogui.FAILSAFE = False
last_action_time = 0


# ---------- Helper Functions ----------
def safe_action(func, *args, **kwargs):
    """Prevent repeated actions"""
    global last_action_time
    if time.time() - last_action_time >= ACTION_DELAY:
        try:
            func(*args, **kwargs)
        except Exception:
            pass
        last_action_time = time.time()


def find_browser_window():
    """Find active browser window with YouTube"""
    for w in gw.getAllWindows():
        title = (w.title or "").lower()
        if any(x in title for x in ["youtube", "chrome", "firefox", "edge", "brave"]):
            return w
    return None


def focus_youtube_and_fullscreen():
    """Activate YouTube window and go fullscreen"""
    win = find_browser_window()
    if win:
        try:
            win.activate()
            time.sleep(1)
            x = win.left + win.width // 2
            y = win.top + win.height // 2
            pyautogui.click(x, y)
            time.sleep(0.5)
            pyautogui.press("f")
            print("✅ YouTube video set to fullscreen.")
        except Exception as e:
            print("⚠️ Fullscreen error:", e)
    else:
        print("❌ YouTube window not found. Open it manually.")


def estimate_yaw(landmarks, w, h):
    """Estimate head yaw (left/right turn)"""
    left = landmarks[33].x * w
    right = landmarks[263].x * w
    nose = landmarks[1].x * w
    mid = (left + right) / 2
    offset = nose - mid
    norm = offset / (abs(right - left) / 2 + 1e-6)
    return norm * 30


def show_rest_popup():
    """Popup suggesting 5-minute rest"""
    def close_popup():
        try:
            root.destroy()
        except Exception:
            pass

    root = Tk()
    root.title("Take a Rest")
    root.geometry("320x150")
    Label(root, text="😔 You look sad.\nTake a 5-minute rest.", font=("Arial", 13)).pack(pady=10)
    Button(root, text="Okay, I will rest", command=close_popup, width=20).pack(pady=5)
    Button(root, text="Skip", command=close_popup, width=20).pack()
    root.mainloop()


# ---------- Main ----------
def main():
    print("🌐 Opening YouTube video...")
    webbrowser.open(YOUTUBE_URL)
    time.sleep(7)
    focus_youtube_and_fullscreen()

    cap = cv2.VideoCapture(0)
    was_paused = False
    sad_start = None

    print("🎥 Smart UI active — press 'q' to quit webcam window.")

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        h, w = frame.shape[:2]
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = face_mesh.process(rgb)

        if results.multi_face_landmarks:
            lm = results.multi_face_landmarks[0].landmark
            yaw = estimate_yaw(lm, w, h)
            abs_yaw = abs(yaw)
            focused = abs_yaw < HEAD_TURN_ANGLE

            # Emotion detection
            emotions = emotion_detector.detect_emotions(frame)
            dominant = "neutral"
            score = 0.0
            if emotions:
                em = emotions[0]["emotions"]
                dominant, score = max(em.items(), key=lambda x: x[1])

            sad = dominant == "sad" and score >= SAD_SCORE_THRESHOLD

            # ---- Sadness detection ----
            if sad:
                if sad_start is None:
                    sad_start = time.time()
                elif time.time() - sad_start >= SAD_TIME:
                    print("😔 You look sad — Take a rest!")
                    safe_action(pyautogui.press, "space")
                    was_paused = True
                    sbc.set_brightness(BRIGHT_NORMAL)
                    threading.Thread(target=show_rest_popup, daemon=True).start()
                    sad_start = None
            else:
                sad_start = None

            # ---- Focused ----
            if focused:
                if was_paused:
                    print("😊 Focus regained → Resuming video.")
                    safe_action(pyautogui.press, "space")
                    was_paused = False
                    sbc.set_brightness(BRIGHT_FOCUS)
                    time.sleep(0.3)
            else:
                if not was_paused:
                    print("↔️ Head turned → Pausing video.")
                    safe_action(pyautogui.press, "space")
                    was_paused = True
                    sbc.set_brightness(BRIGHT_NORMAL)

            # Overlay debug text
            cv2.putText(frame, f"Yaw:{int(yaw)} | Mood:{dominant}({score:.2f}) | Focus:{focused}",
                        (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6,
                        (0, 255, 0) if focused else (0, 0, 255), 2)
        else:
            cv2.putText(frame, "No face detected", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)

        cv2.imshow("Smart UI - Mood & Focus", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
